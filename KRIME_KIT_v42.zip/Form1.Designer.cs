﻿namespace KRIME_KIT_v42
{
    partial class Form1
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.txtAdbLog = new System.Windows.Forms.TextBox();
            this.button4 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.flowLayoutPanel4 = new System.Windows.Forms.FlowLayoutPanel();
            this.flowLayoutPanel5 = new System.Windows.Forms.FlowLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBoxDeviceInfo = new System.Windows.Forms.GroupBox();
            this.valueMacAddress = new System.Windows.Forms.Label();
            this.valueIpAddress = new System.Windows.Forms.Label();
            this.valueAdbStatus = new System.Windows.Forms.Label();
            this.valueUsbDevice = new System.Windows.Forms.Label();
            this.labelMacAddress = new System.Windows.Forms.Label();
            this.labelIpAddress = new System.Windows.Forms.Label();
            this.labelAdbStatus = new System.Windows.Forms.Label();
            this.labelUsbDevice = new System.Windows.Forms.Label();
            this.groupBoxNetworkInfo = new System.Windows.Forms.GroupBox();
            this.labelPassword = new System.Windows.Forms.Label();
            this.labelGateway = new System.Windows.Forms.Label();
            this.labelIP = new System.Windows.Forms.Label();
            this.labelSSID = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBoxDeviceInfo.SuspendLayout();
            this.groupBoxNetworkInfo.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(19, 228);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "SCRCPY";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.btnStartScrcpy_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button2.Font = new System.Drawing.Font("Franklin Gothic Medium", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.Lime;
            this.button2.Location = new System.Drawing.Point(117, 228);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 1;
            this.button2.Text = "TERMINAL";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.btnScrcpyTerminal_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(237, 228);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(87, 23);
            this.button7.TabIndex = 6;
            this.button7.Text = "HOTSPOT";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.btnHotspot_Click);
            // 
            // txtAdbLog
            // 
            this.txtAdbLog.BackColor = System.Drawing.Color.Black;
            this.txtAdbLog.Location = new System.Drawing.Point(3, 346);
            this.txtAdbLog.Multiline = true;
            this.txtAdbLog.Name = "txtAdbLog";
            this.txtAdbLog.Size = new System.Drawing.Size(347, 98);
            this.txtAdbLog.TabIndex = 7;
            this.txtAdbLog.TextChanged += new System.EventHandler(this.txtAdbLog_TextChanged);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(10, 293);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 9;
            this.button4.Text = "REBOOT";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.btnReboot_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(91, 293);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 23);
            this.button6.TabIndex = 11;
            this.button6.Text = "FASTBOOT";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.btnFastboot_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(172, 293);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 23);
            this.button5.TabIndex = 12;
            this.button5.Text = "RECOVERY";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.btnRecovery_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button3.ForeColor = System.Drawing.Color.Lime;
            this.button3.Location = new System.Drawing.Point(265, 293);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(76, 23);
            this.button3.TabIndex = 10;
            this.button3.Text = "TERMINAL";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.btnAdbTerminal_Click);
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.BackColor = System.Drawing.SystemColors.MenuText;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(12, 218);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(188, 42);
            this.flowLayoutPanel1.TabIndex = 13;
            // 
            // flowLayoutPanel4
            // 
            this.flowLayoutPanel4.BackColor = System.Drawing.SystemColors.MenuText;
            this.flowLayoutPanel4.Location = new System.Drawing.Point(218, 218);
            this.flowLayoutPanel4.Name = "flowLayoutPanel4";
            this.flowLayoutPanel4.Size = new System.Drawing.Size(123, 42);
            this.flowLayoutPanel4.TabIndex = 14;
            // 
            // flowLayoutPanel5
            // 
            this.flowLayoutPanel5.BackColor = System.Drawing.SystemColors.MenuText;
            this.flowLayoutPanel5.Location = new System.Drawing.Point(3, 284);
            this.flowLayoutPanel5.Name = "flowLayoutPanel5";
            this.flowLayoutPanel5.Size = new System.Drawing.Size(347, 42);
            this.flowLayoutPanel5.TabIndex = 14;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Black;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(15, 203);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 13);
            this.label1.TabIndex = 15;
            this.label1.Text = "SCRCPY";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Black;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(221, 205);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(70, 13);
            this.label2.TabIndex = 16;
            this.label2.Text = "NETWORK";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Black;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(11, 270);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(32, 13);
            this.label3.TabIndex = 17;
            this.label3.Text = "ADB";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Black;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(5, 335);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(36, 13);
            this.label4.TabIndex = 18;
            this.label4.Text = "LOGS";
            // 
            // groupBoxDeviceInfo
            // 
            this.groupBoxDeviceInfo.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.groupBoxDeviceInfo.Controls.Add(this.valueMacAddress);
            this.groupBoxDeviceInfo.Controls.Add(this.valueIpAddress);
            this.groupBoxDeviceInfo.Controls.Add(this.valueAdbStatus);
            this.groupBoxDeviceInfo.Controls.Add(this.valueUsbDevice);
            this.groupBoxDeviceInfo.Controls.Add(this.labelMacAddress);
            this.groupBoxDeviceInfo.Controls.Add(this.labelIpAddress);
            this.groupBoxDeviceInfo.Controls.Add(this.labelAdbStatus);
            this.groupBoxDeviceInfo.Controls.Add(this.labelUsbDevice);
            this.groupBoxDeviceInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxDeviceInfo.ForeColor = System.Drawing.Color.Red;
            this.groupBoxDeviceInfo.Location = new System.Drawing.Point(6, 89);
            this.groupBoxDeviceInfo.Name = "groupBoxDeviceInfo";
            this.groupBoxDeviceInfo.Size = new System.Drawing.Size(164, 88);
            this.groupBoxDeviceInfo.TabIndex = 19;
            this.groupBoxDeviceInfo.TabStop = false;
            this.groupBoxDeviceInfo.Text = "DEVICE INFO";
            // 
            // valueMacAddress
            // 
            this.valueMacAddress.AutoSize = true;
            this.valueMacAddress.Font = new System.Drawing.Font("Franklin Gothic Medium", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.valueMacAddress.ForeColor = System.Drawing.Color.White;
            this.valueMacAddress.Location = new System.Drawing.Point(45, 66);
            this.valueMacAddress.Name = "valueMacAddress";
            this.valueMacAddress.Size = new System.Drawing.Size(10, 15);
            this.valueMacAddress.TabIndex = 7;
            this.valueMacAddress.Text = "-";
            // 
            // valueIpAddress
            // 
            this.valueIpAddress.AutoSize = true;
            this.valueIpAddress.Font = new System.Drawing.Font("Franklin Gothic Medium", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.valueIpAddress.ForeColor = System.Drawing.Color.White;
            this.valueIpAddress.Location = new System.Drawing.Point(32, 50);
            this.valueIpAddress.Name = "valueIpAddress";
            this.valueIpAddress.Size = new System.Drawing.Size(10, 15);
            this.valueIpAddress.TabIndex = 6;
            this.valueIpAddress.Text = "-";
            // 
            // valueAdbStatus
            // 
            this.valueAdbStatus.AutoSize = true;
            this.valueAdbStatus.Font = new System.Drawing.Font("Franklin Gothic Medium", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.valueAdbStatus.ForeColor = System.Drawing.Color.White;
            this.valueAdbStatus.Location = new System.Drawing.Point(43, 34);
            this.valueAdbStatus.Name = "valueAdbStatus";
            this.valueAdbStatus.Size = new System.Drawing.Size(10, 15);
            this.valueAdbStatus.TabIndex = 5;
            this.valueAdbStatus.Text = "-";
            // 
            // valueUsbDevice
            // 
            this.valueUsbDevice.AutoSize = true;
            this.valueUsbDevice.Font = new System.Drawing.Font("Franklin Gothic Medium", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.valueUsbDevice.ForeColor = System.Drawing.Color.White;
            this.valueUsbDevice.Location = new System.Drawing.Point(60, 18);
            this.valueUsbDevice.Name = "valueUsbDevice";
            this.valueUsbDevice.Size = new System.Drawing.Size(10, 15);
            this.valueUsbDevice.TabIndex = 4;
            this.valueUsbDevice.Text = "-";
            // 
            // labelMacAddress
            // 
            this.labelMacAddress.AutoSize = true;
            this.labelMacAddress.Font = new System.Drawing.Font("Franklin Gothic Medium", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMacAddress.ForeColor = System.Drawing.Color.White;
            this.labelMacAddress.Location = new System.Drawing.Point(5, 66);
            this.labelMacAddress.Name = "labelMacAddress";
            this.labelMacAddress.Size = new System.Drawing.Size(40, 15);
            this.labelMacAddress.TabIndex = 3;
            this.labelMacAddress.Text = "MAC :";
            // 
            // labelIpAddress
            // 
            this.labelIpAddress.AutoSize = true;
            this.labelIpAddress.Font = new System.Drawing.Font("Franklin Gothic Medium", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelIpAddress.ForeColor = System.Drawing.Color.White;
            this.labelIpAddress.Location = new System.Drawing.Point(5, 50);
            this.labelIpAddress.Name = "labelIpAddress";
            this.labelIpAddress.Size = new System.Drawing.Size(27, 15);
            this.labelIpAddress.TabIndex = 2;
            this.labelIpAddress.Text = "IP :";
            this.labelIpAddress.Click += new System.EventHandler(this.label8_Click);
            // 
            // labelAdbStatus
            // 
            this.labelAdbStatus.AutoSize = true;
            this.labelAdbStatus.Font = new System.Drawing.Font("Franklin Gothic Medium", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAdbStatus.ForeColor = System.Drawing.Color.White;
            this.labelAdbStatus.Location = new System.Drawing.Point(5, 34);
            this.labelAdbStatus.Name = "labelAdbStatus";
            this.labelAdbStatus.Size = new System.Drawing.Size(39, 15);
            this.labelAdbStatus.TabIndex = 1;
            this.labelAdbStatus.Text = "ADB :";
            // 
            // labelUsbDevice
            // 
            this.labelUsbDevice.AutoSize = true;
            this.labelUsbDevice.Font = new System.Drawing.Font("Franklin Gothic Medium", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelUsbDevice.ForeColor = System.Drawing.Color.White;
            this.labelUsbDevice.Location = new System.Drawing.Point(5, 18);
            this.labelUsbDevice.Name = "labelUsbDevice";
            this.labelUsbDevice.Size = new System.Drawing.Size(55, 15);
            this.labelUsbDevice.TabIndex = 0;
            this.labelUsbDevice.Text = "DEVICE :";
            // 
            // groupBoxNetworkInfo
            // 
            this.groupBoxNetworkInfo.Controls.Add(this.label5);
            this.groupBoxNetworkInfo.Controls.Add(this.label6);
            this.groupBoxNetworkInfo.Controls.Add(this.label7);
            this.groupBoxNetworkInfo.Controls.Add(this.label8);
            this.groupBoxNetworkInfo.Controls.Add(this.labelPassword);
            this.groupBoxNetworkInfo.Controls.Add(this.labelSSID);
            this.groupBoxNetworkInfo.Controls.Add(this.labelGateway);
            this.groupBoxNetworkInfo.Controls.Add(this.labelIP);
            this.groupBoxNetworkInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxNetworkInfo.Location = new System.Drawing.Point(174, 89);
            this.groupBoxNetworkInfo.Name = "groupBoxNetworkInfo";
            this.groupBoxNetworkInfo.Size = new System.Drawing.Size(173, 88);
            this.groupBoxNetworkInfo.TabIndex = 20;
            this.groupBoxNetworkInfo.TabStop = false;
            this.groupBoxNetworkInfo.Text = "NETWORK INFO";
            // 
            // labelPassword
            // 
            this.labelPassword.AutoSize = true;
            this.labelPassword.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.labelPassword.Font = new System.Drawing.Font("Franklin Gothic Medium", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPassword.ForeColor = System.Drawing.Color.White;
            this.labelPassword.Location = new System.Drawing.Point(4, 68);
            this.labelPassword.Name = "labelPassword";
            this.labelPassword.Size = new System.Drawing.Size(79, 15);
            this.labelPassword.TabIndex = 11;
            this.labelPassword.Text = "PASSWORD :";
            // 
            // labelGateway
            // 
            this.labelGateway.AutoSize = true;
            this.labelGateway.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.labelGateway.Font = new System.Drawing.Font("Franklin Gothic Medium", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelGateway.ForeColor = System.Drawing.Color.White;
            this.labelGateway.Location = new System.Drawing.Point(4, 51);
            this.labelGateway.Name = "labelGateway";
            this.labelGateway.Size = new System.Drawing.Size(69, 15);
            this.labelGateway.TabIndex = 10;
            this.labelGateway.Text = "GATEWAY :";
            // 
            // labelIP
            // 
            this.labelIP.AutoSize = true;
            this.labelIP.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.labelIP.Font = new System.Drawing.Font("Franklin Gothic Medium", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelIP.ForeColor = System.Drawing.Color.White;
            this.labelIP.Location = new System.Drawing.Point(4, 34);
            this.labelIP.Name = "labelIP";
            this.labelIP.Size = new System.Drawing.Size(50, 15);
            this.labelIP.TabIndex = 9;
            this.labelIP.Text = "Wlan0 :";
            // 
            // labelSSID
            // 
            this.labelSSID.AutoSize = true;
            this.labelSSID.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.labelSSID.Font = new System.Drawing.Font("Franklin Gothic Medium", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSSID.ForeColor = System.Drawing.Color.White;
            this.labelSSID.Location = new System.Drawing.Point(4, 17);
            this.labelSSID.Name = "labelSSID";
            this.labelSSID.Size = new System.Drawing.Size(41, 15);
            this.labelSSID.TabIndex = 8;
            this.labelSSID.Text = "SSID :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Franklin Gothic Medium", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(84, 68);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(10, 15);
            this.label5.TabIndex = 15;
            this.label5.Text = "-";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Franklin Gothic Medium", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(46, 17);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(10, 15);
            this.label6.TabIndex = 12;
            this.label6.Text = "-";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Franklin Gothic Medium", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(74, 51);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(10, 15);
            this.label7.TabIndex = 14;
            this.label7.Text = "-";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Franklin Gothic Medium", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(55, 34);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(10, 15);
            this.label8.TabIndex = 13;
            this.label8.Text = "-";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(353, 456);
            this.Controls.Add(this.groupBoxNetworkInfo);
            this.Controls.Add(this.groupBoxDeviceInfo);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txtAdbLog);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.flowLayoutPanel4);
            this.Controls.Add(this.flowLayoutPanel5);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "KRIME_KIT_v42";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBoxDeviceInfo.ResumeLayout(false);
            this.groupBoxDeviceInfo.PerformLayout();
            this.groupBoxNetworkInfo.ResumeLayout(false);
            this.groupBoxNetworkInfo.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.TextBox txtAdbLog;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel4;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBoxDeviceInfo;
        private System.Windows.Forms.Label labelAdbStatus;
        private System.Windows.Forms.Label labelUsbDevice;
        private System.Windows.Forms.GroupBox groupBoxNetworkInfo;
        private System.Windows.Forms.Label labelMacAddress;
        private System.Windows.Forms.Label labelIpAddress;
        private System.Windows.Forms.Label valueMacAddress;
        private System.Windows.Forms.Label valueIpAddress;
        private System.Windows.Forms.Label valueAdbStatus;
        private System.Windows.Forms.Label valueUsbDevice;
        private System.Windows.Forms.Label labelPassword;
        private System.Windows.Forms.Label labelSSID;
        private System.Windows.Forms.Label labelGateway;
        private System.Windows.Forms.Label labelIP;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
    }
}

