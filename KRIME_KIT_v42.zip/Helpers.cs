﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using System.IO;

namespace KRIME_KIT_v42
{
    public static class Helpers
    {
        private static string RunAdbCommand(string arguments)
        {
            try
            {
                // 🔽 Récupère le chemin de l'exécutable
                string basePath = AppDomain.CurrentDomain.BaseDirectory;

                // 🔽 Chemin vers adb.exe dans ton dossier de projet
                string adbPath = Path.Combine(basePath, "Repos", "platform-tools", "adb.exe");

                if (!File.Exists(adbPath))
                    return "ADB not found at: " + adbPath;

                ProcessStartInfo psi = new ProcessStartInfo
                {
                    FileName = adbPath,
                    Arguments = arguments,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    UseShellExecute = false,
                    CreateNoWindow = true
                };

                using (Process process = Process.Start(psi))
                {
                    process.WaitForExit();
                    string output = process.StandardOutput.ReadToEnd().Trim();
                    string error = process.StandardError.ReadToEnd().Trim();

                    return string.IsNullOrWhiteSpace(output) ? error : output;
                }
            }
            catch (Exception ex)
            {
                return $"Erreur ADB: {ex.Message}";
            }
        }

        // 🔽🔽🔽 Ajoute cette méthode :
        public static string GetDeviceName()
        {
            string result = RunAdbCommand("shell getprop ro.product.model");
            return string.IsNullOrWhiteSpace(result) ? "Inconnu" : result;
        }

        public static string GetAdbStatus()
        {
            string result = RunAdbCommand("devices");
            if (result.Contains("\tdevice"))
                return "Connecté";
            else if (result.Contains("\tunauthorized"))
                return "Non autorisé";
            else
                return "Aucun appareil";
        }

        public static string GetIpAddress()
        {
            string result = RunAdbCommand("shell ip -f inet addr show wlan0");
            if (result.Contains("inet "))
            {
                int start = result.IndexOf("inet ") + 5;
                int end = result.IndexOf("/", start);
                return result.Substring(start, end - start);
            }
            return "IP non détectée";
        }

        public static string GetMacAddress()
        {
            string result = RunAdbCommand("shell cat /sys/class/net/wlan0/address");
            return string.IsNullOrWhiteSpace(result) ? "Non détectée" : result;
        }
    }
}
