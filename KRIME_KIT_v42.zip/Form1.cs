﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KRIME_KIT_v42
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void btnStartScrcpy_Click(object sender, EventArgs e)
        {
            try
            {
                // Get the full path to the SCRCPY folder
                string projectRoot = AppDomain.CurrentDomain.BaseDirectory;
                string scrcpyPath = Path.Combine(projectRoot, "Repos", "SCRCPY", "scrcpy.exe");

                if (File.Exists(scrcpyPath))
                {
                    ProcessStartInfo startInfo = new ProcessStartInfo
                    {
                        FileName = scrcpyPath,
                        WorkingDirectory = Path.GetDirectoryName(scrcpyPath),
                        UseShellExecute = true
                    };

                    Process.Start(startInfo);
                }
                else
                {
                    MessageBox.Show("scrcpy.exe not found in the /Repos/SCRCPY folder.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error starting scrcpy: " + ex.Message, "Exception", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnScrcpyTerminal_Click(object sender, EventArgs e)
        {
            try
            {
                string scrcpyDir = Path.Combine(Application.StartupPath, "Repos", "SCRCPY");

                if (!Directory.Exists(scrcpyDir))
                {
                    MessageBox.Show("Le dossier SCRCPY est introuvable : " + scrcpyDir, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                ProcessStartInfo psi = new ProcessStartInfo
                {
                    FileName = "cmd.exe",
                    WorkingDirectory = scrcpyDir,
                    UseShellExecute = true
                };

                Process.Start(psi);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de l'ouverture du terminal SCRCPY : " + ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnHotspot_Click(object sender, EventArgs e)
{
    try
    {
        Process.Start(new ProcessStartInfo
        {
            FileName = "ms-settings:network-mobilehotspot",
            UseShellExecute = true
        });
    }
    catch (Exception ex)
    {
        MessageBox.Show("Unable to open Hotspot settings: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
    }
        }

        private void RunAdbCommand(string arguments)
        {
            try
            {
                string adbDir = Path.Combine(Application.StartupPath, "Repos", "platform-tools");
                string adbPath = Path.Combine(adbDir, "adb.exe");

                if (!File.Exists(adbPath))
                {
                    AppendLog("❌ adb.exe introuvable dans : " + adbDir);
                    return;
                }

                ProcessStartInfo psi = new ProcessStartInfo
                {
                    FileName = adbPath,
                    Arguments = arguments,
                    WorkingDirectory = adbDir,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    UseShellExecute = false,
                    CreateNoWindow = true
                };

                using (Process process = Process.Start(psi))
                {
                    string output = process.StandardOutput.ReadToEnd();
                    string error = process.StandardError.ReadToEnd();
                    process.WaitForExit();

                    AppendLog($"▶️ Commande : adb {arguments}");

                    if (!string.IsNullOrWhiteSpace(output))
                        AppendLog("✅ Sortie :\n" + output);

                    if (!string.IsNullOrWhiteSpace(error))
                        AppendLog("⚠️ Erreur :\n" + error);
                }
            }
            catch (Exception ex)
            {
                AppendLog("❗ Exception : " + ex.Message);
            }
        }


        private void btnReboot_Click(object sender, EventArgs e)
        {
            RunAdbCommand("reboot");
        }

        private void btnFastboot_Click(object sender, EventArgs e)
        {
            RunAdbCommand("reboot fastboot");
        }

        private void btnRecovery_Click(object sender, EventArgs e)
        {
            RunAdbCommand("reboot recovery");
        }

        private void AppendLog(string text)
        {
            if (txtAdbLog.InvokeRequired)
            {
                txtAdbLog.Invoke(new Action(() => AppendLog(text)));
            }
            else
            {
                txtAdbLog.AppendText(text + Environment.NewLine);
                txtAdbLog.ScrollToCaret();
            }
        }

        private void btnAdbTerminal_Click(object sender, EventArgs e)
        {
            try
            {
                string adbDir = Path.Combine(Application.StartupPath, "Repos", "platform-tools");

                if (!Directory.Exists(adbDir))
                {
                    MessageBox.Show("Le dossier platform-tools est introuvable : " + adbDir, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                ProcessStartInfo psi = new ProcessStartInfo
                {
                    FileName = "cmd.exe",
                    WorkingDirectory = adbDir,
                    UseShellExecute = true
                };

                Process.Start(psi);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de l'ouverture du terminal ADB : " + ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void txtAdbLog_TextChanged(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            valueUsbDevice.Text = Helpers.GetDeviceName();
            valueAdbStatus.Text = Helpers.GetAdbStatus();
            valueIpAddress.Text = Helpers.GetIpAddress();
            valueMacAddress.Text = Helpers.GetMacAddress();
            labelSSID.Text = NetworkHelpers.GetSSID();
            labelIP.Text = NetworkHelpers.GetIPAddress();
            labelGateway.Text = NetworkHelpers.GetGateway();
            labelPassword.Text = NetworkHelpers.GetWifiPassword();
        }

    }
}


