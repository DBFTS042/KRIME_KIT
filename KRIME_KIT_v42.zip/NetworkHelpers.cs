﻿using System;
using System.Diagnostics;
using System.IO;
using System.Text.RegularExpressions;

public static class NetworkHelpers
{
    // Exécute une commande PowerShell et retourne la sortie
    private static string RunPowerShellCommand(string command)
    {
        ProcessStartInfo psi = new ProcessStartInfo
        {
            FileName = "powershell.exe",
            Arguments = "-Command \"" + command + "\"",
            RedirectStandardOutput = true,
            UseShellExecute = false,
            CreateNoWindow = true
        };

        using (Process process = Process.Start(psi))
        {
            return process.StandardOutput.ReadToEnd().Trim();
        }
    }

    public static string GetSSID()
    {
        string result = RunPowerShellCommand("netsh wlan show interfaces");
        var match = Regex.Match(result, @"^\s*SSID\s*:\s(.+)$", RegexOptions.Multiline);
        return match.Success ? match.Groups[1].Value.Trim() : "Inconnu";
    }

    public static string GetIPAddress()
    {
        string result = RunPowerShellCommand("Get-NetIPAddress -InterfaceAlias 'Wi-Fi' | Where-Object {$_.AddressFamily -eq 'IPv4'} | Select-Object -ExpandProperty IPAddress");
        return string.IsNullOrWhiteSpace(result) ? "Non détectée" : result;
    }

    public static string GetGateway()
    {
        string result = RunPowerShellCommand("Get-NetRoute -InterfaceAlias 'Wi-Fi' | Where-Object { $_.DestinationPrefix -eq '0.0.0.0/0' } | Select-Object -ExpandProperty NextHop");
        return string.IsNullOrWhiteSpace(result) ? "Non détectée" : result;
    }

    public static string GetWifiPassword()
    {
        string ssid = GetSSID();
        if (ssid == "Inconnu")
            return "Non disponible";

        string result = RunPowerShellCommand($"netsh wlan show profile name=\"{ssid}\" key=clear");
        var match = Regex.Match(result, @"Key Content\s*:\s(.+)", RegexOptions.IgnoreCase);
        return match.Success ? match.Groups[1].Value.Trim() : "Non trouvée";
    }
}

